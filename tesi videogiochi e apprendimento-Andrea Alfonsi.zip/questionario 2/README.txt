ENG
These data are international in nature. They were collected from major social networks, including Facebook, Reddit, Twitter (currently X), WhatsApp, and Telegram.


ITA:
Questi dati sono di natura internazionale. Sono stati raccolti dai principali social network, tra cui Facebook, Reddit, Twitter (attualmente X), WhatsApp e Telegram.