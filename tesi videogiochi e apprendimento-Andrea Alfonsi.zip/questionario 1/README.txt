ENG:
These data pertain exclusively to Italian people or individuals present in Italian territory. The data were collected from major social networks such as Facebook, Reddit, Twitter (currently X), WhatsApp, and Telegram

ITA:
Questi dati riguardano esclusivamente persone italiane o presenti sul territorio italiano. I dati sono stati raccolti dai principali social network, come Facebook, Reddit, Twitter (attualmente X), WhatsApp e Telegram.