ENG:
As with the Cesare Musatti Professional Institute, I was granted permission to administer this questionnaire at another school, ITCS Maria Lazzari, where the principal was the same. However, in this case, I do not have a specific circular.

ITA:
Come per l'Istituto Professionale Cesare Musatti, mi è stato concesso di somministrare tale questionario anche a un'altra scuola, l'ITCS Maria Lazzari, dove il preside era lo stesso. In questo caso, però, non dispongo di una circolare specifica.