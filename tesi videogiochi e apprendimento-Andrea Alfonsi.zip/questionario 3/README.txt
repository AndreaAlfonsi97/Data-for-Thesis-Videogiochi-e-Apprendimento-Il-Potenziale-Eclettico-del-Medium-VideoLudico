ENG:
This document was prepared in collaboration with the Cesare Musatti Professional Institute, with the principal's authorization granted through circular 614, available within this repository.


ITA:
Questo documento è stato realizzato in collaborazione con l'Istituto Professionale Cesare Musatti, con l'autorizzazione del preside concessa tramite la circolare 614, disponibile all'interno di questa repository.