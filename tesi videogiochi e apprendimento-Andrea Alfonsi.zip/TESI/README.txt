ENG:
These are the documents submitted as a thesis to the University Ecclesia Mater. The documents include the thesis and Annex A.


ITA
Questi sono i documenti presentati come tesi all'Università Ecclesia Mater. I documenti includono la tesi e l'Allegato A-