ENG:

These are all the interviews I conducted for the thesis. The text has not been translated into English, but interviewees outside of Italy were provided with a translation into Italian. I have kept the original version within this text.

ITA:

Queste sono tutte le interviste che ho condotto per la tesi. Il testo non è stato tradotto in lingua inglese, ma per gli intervistati al di fuori dell'Italia è stata fornita una traduzione in italiano. Ho mantenuto la versione originale all'interno di questo testo.